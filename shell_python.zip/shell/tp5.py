#! /usr/bin/env python
#-*- coding: utf-8 -*-

import os,sys

path=sys.argv[1]
cmd='cat ' +path + '| sort'
file=os.popen(cmd)
line=file.readlines()

print line

file.close()
