#! /bin/bash
N=6
for i in $(seq 0 6)
do
	for j in $(seq 0 $N)
	do
		echo -n "  "
	done

	for k in $(seq 0 $i)
	do
		echo -n " *  "
	done
	echo
	N=$((N-1))
done
 
M=6
for y in $(seq 0 6)
do

	for n in $(seq 0 $y)
	do
		echo -n "  "
	done

	for x in $(seq 0 $M)
	do
		echo -n " *  "
	done
	echo
	M=$((M-1))
done
