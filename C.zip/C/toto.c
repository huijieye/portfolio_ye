#include <stdio.h>

int main()
{
  int a,b;

	printf("veuillez saisir 2 nombres entieres a et b:");
	scanf("%d",a);
	scanf("%d",b);

  if(a<b)
{
	int i=2;
	int r;
	r=a mod i;

	if(r=0)
	{
	 printf("%d n'est pas un nombre premier.\n",a);
	 a++;
	}
	else
	{
	 	if(i<=b)
		{
		 r=a mod i;
		}
		else
		{printf("%d est un nombre premier",a);
		  a++;	}
	}
}
 
  return 0;
  }

