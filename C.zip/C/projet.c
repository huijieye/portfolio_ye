#include <stdio.h>
#include <stdlib.h>
#include <string.h>


enum {TAILLE_STR=10};

typedef struct
{
	char  pays[TAILLE_STR];
	unsigned int pib;
	char capitale [TAILLE_STR];
	int latitutude;
	int longitude;
} Pays;

typedef struct
{
	Pays miniTable[5];
	char choix [5];
	unsigned int taille;

}Monde;



void insertion (Monde* in)
{
	char pays,capitale;
	unsigned int pib;
	int latitude, longitude;

printf ("saisissez le nouveau pays \n")	;
scanf ("%20s %d %s %d %d",&pays,&pib,&capitale,&latitude,&longitude);

}


void QueryL(char L1, char L2)
{
  int i;

}


void delete (Mond* de)
{ int i,y;


  while (i<=y) {
if (i==y)
{
Monde[i].pays=" ";
}
i++;






void selection (Monde* se)
{
  // char pays[]="pays",capitale[]="capitale";
    //    unsigned int pib;
    int inteMaxN, inteMinN;//inteMaxN, inteMinN=nombre; inteMaxC=caractere
    char inteMaxC, inteMinC;
    int critere; //1 pays contient 5 criteres
    // int colonne[5];
    int x;
// critere, colonne,inteMin,inteMax

	printf ("critere, colonne,inteMin,inteMax?\n"); //critere de 1 à 5
	scanf ("%d", &critere);

switch(critere)
{
case 1:
    printf ("x= ?\n");
    scanf ("%d", &x);

    if (x == 1 || x == 3)

            {

              printf  ("Veuillez saisir l'intervalle\n");
              scanf ("%c, %c", &inteMinC,&inteMaxC);
	      QueryL(inteMinC, inteMaxC);
	      break;
            }
    
    else if (x == 2 || x  == 4 || x == 5)
      
      
               {
		 printf  ("l'intervale miniN et l'intervalle maxi?\n");
		 scanf ("%d %d", &inteMinN,&inteMaxN);
		 break;
               }
 }
}
    





void delete 



int main()
{
	char mot[TAILLE_STR];
       

/*initialiser(in);*/

	Monde monde;
   
	while (1)
	{
	 
	  printf("Veuillez saisir le cmd (insert/select) pour commencer\n");
	  scanf ("%79s",mot);
	  printf ("%s\n",mot);
	  
	  

	  if (strcmp(mot, "insert")==0)
	    
	    {
	      
	      insertion(&monde);
	      
	      
	    }
	  if (strcmp(mot, "select")==0)
	    
	    {
	      
	      selection(&monde);
	    }
	  
	  if (strcmp(mot, "exit")==0)
	    {
	      
	      exit(0);
	      printf ("exit\n");
	      
	    }
	  
	}
	system("pause");
	return 0;
}
