#include <stdio.h>


int main()
{
int nl,nc,nb_mine; // ligne, colonne et nombre de mine

	printf("Bienvenu au jeu du démineur!");

void saisie()
{
	printf("Veuillez saisir le nombre de ligne");
	scanf("%d",&nl);

	printf("Veuillez saisir le nombre de colonne");
	scanf("%d",&nc);

	printf("Veuillez saisir le nombre de mine");
	scanf("%d",&nb_mine);
}

return 0;
}
