#include <stdio.h>

int main()
{ int i,j,x;
  int nb;
  j=0;

printf("Entrer un nombre entre 5 et 9: ");
scanf("%d", &nb);  

  while(j<nb)
    { for(i=nb;i>j;i--)
	
        {
	  printf(" ");
	}
      for(x=0;x<=j;x++)
	{              
	  printf(" * ");
          
        }	
      printf("\n");
      j++;

	}
 
  return 0;
}


