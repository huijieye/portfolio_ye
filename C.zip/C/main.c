#include <stdio.h>
#include <stdlib.h>
#include <string.h>


enum {TAILLE_STR=200};

typedef struct
{
	char  pays[TAILLE_STR];
	unsigned int pib;
	char capitale [TAILLE_STR];
	int latitutude;
	int longitude;
} Pays;

typedef struct
{
	Pays miniTable[100];
	char choix [100];
	unsigned int taille;

}Monde;

typedef enum {TRUE, FALSE} Boolean;

/*void initialiser ( pays* ) // initialiser les structures = 0
{

    int i;
    char  pays[TAILLE_STR];
   for (i=0; i<pays; ++i)

        pays[i]=i;


}

*/


void insertion (Monde* in)
{
	char pays,capitale;
	unsigned int pib;
	int latitude, longitude;

printf ("saisissez le nouveau pays \n")	;
scanf ("%79s %d %s %d %d",&pays,&pib,&capitale,&latitude,&longitude);

}


void selection (Monde* se)
{
    char pays[]="pays",capitale[]="capitale";
	unsigned int pib;
	int latitude, longitude, inteMaxN, inteMinN,  i=1, j;//inteMaxN, inteMinN=nombre; inteMaxC=caractere
    char inteMaxC, inteMinC;
    int critere; //1 pays contient 5 criteres
    int colonne[5];
    colonne[1]=pays;//colonne=
    colonne[2]=pib;
    colonne[3]=capitale;
    colonne[4]=latitude;
    colonne[5]=longitude;

// critere, colonne,inteMin,inteMax

	printf ("critere, colonne,inteMin,inteMax?\n"); //critere de 1��5
	scanf ("%d", &critere);

switch(critere)
{
case 1:
    printf ("colonne?\n");
    scanf ("%s", &colonne);

if (colonne==1 || colonne==3)

            {

              printf  ("lol\n");
              scanf ("%s %s", &inteMinC,&inteMaxC);

            }

    else if (colonne == 2 || colonne == 4 || colonne ==5)


               {
                   printf  ("l'intervale miniN et l'intervalle maxi?\n");
                scanf ("%d %d", &inteMinN,&inteMaxN);
               }

break;

case 2:

    printf ("colonne  inteMin et inteMax\n");
    scanf ("%d %d", &colonne,&colonne);

    if (colonne == 1 || colonne == 3)
            {
               printf  ("l'intervale mini et l'intervalle maxi?\n");
               scanf ("%c %c", &inteMinC,&inteMinC);
            }
             else if(colonne==2 || colonne==4 || colonne==5 )
            {
               printf  ("l'intervale mini et l'intervalle maxi?\n");
               scanf ("%d %d", &inteMinN,&inteMinN);
            }

case 3:
        printf ("colonne  inteMin et inteMax\n");
        scanf ("%d %d %d", &colonne,&colonne,&colonne);

if (colonne==1 || colonne==3)
            {
               printf  ("l'intervale mini et l'intervalle maxi?\n");
               scanf ("%c %c", &inteMinC,&inteMinC);
            }
             else if(colonne==2 || colonne==4 || colonne==5 )
            {
               printf  ("l'intervale mini et l'intervalle maxi?\n");
               scanf ("%d %d", &inteMinN,&inteMinN);
            }
 break;

 case 4:

            printf ("colonne  inteMin et inteMax\n");
            scanf ("%d %d %d %d", &colonne,&colonne,&colonne,&colonne);
if (colonne==1 || colonne==3)
            {
               printf  ("l'intervale mini et l'intervalle maxi?\n");
               scanf ("%c %c", &inteMinC,&inteMinC);
            }
             else if(colonne==2 || colonne==4 || colonne==5 )
            {
               printf  ("l'intervale mini et l'intervalle maxi?\n");
               scanf ("%d %d", &inteMinN,&inteMinN);
            }
               break;

 case 5:

        printf ("colonne  inteMin et inteMax\n");
        scanf ("%d %d %d %d %d", &colonne,&colonne,&colonne,&colonne,&colonne);
if (colonne==1 || colonne==3)
            {
               printf  ("l'intervale mini et l'intervalle maxi?\n");
               scanf ("%c %c", &inteMinC,&inteMinC);
            }
             else if(colonne==2 || colonne==4 || colonne==5 )
            {
               printf  ("l'intervale mini et l'intervalle maxi?\n");
               scanf ("%d %d", &inteMinN,&inteMinN);
            }
 break;
 default: printf ("erreur\n");
 break;

}





    for (j=1; j>=colonne; j++)

        {
            if (colonne==1 || colonne==3)
            {
               printf  ("l'intervale mini et l'intervalle maxi?\n");
               scanf ("%c %c", &inteMin,&inteMin);
            }
             if (colonne==2 || colonne==4 || colonne==5 )
            {
               printf  ("l'intervale mini et l'intervalle maxi?\n");
               scanf ("%d %d", &inteMin,&inteMin);
            }


}











/*void suppression ()
{



}



*/
int main()
{
	char mot[TAILLE_STR];
	int taille;

/*initialiser(in);*/

	Monde monde;
	monde.taille=0;



	while (1)
	{
		scanf ("%79s",mot);
		printf ("%s\n",mot);



	if (strcmp(mot, "insert")==0)

		{

		insertion(&monde);


		}

	/*if (strcmp(mot, "delete")==0)

		{

		suppression();
		}

*/
    if (strcmp(mot, "select")==0)

		{

		selection(&monde);
		}

	if (strcmp(mot, "exit")==0)
		{

		exit(0);
		printf ("exit\n");

		}

    }
    system("pause"); return 0;

}

