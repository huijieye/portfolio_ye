#include <stdio.h>

int main()
{
 int  a;
 int  b;
 int  c;
 int min;
   printf("saisir a,b,c");
   scanf("%d",&a);
   scanf("%d",&b);
   scanf("%d",&c);


   if (a<b)
   {
   	  if (b<c)
   	 {
	   min=a;
    	 }
   }
    else
    {
	  if(b>c)
          {
	    min=c;
          }
          else
	    min=b;
     }

      

	printf("min=%d\n", min);

	return 0;
}
