<html>
<head>
	<title>Formulaire</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="formulaire.css"/>
</head>
<body>

	<form method="POST" action="traitement.php">
	
		<h1>Adresse Client</h1>
	
		<label for="nom">Nom</label>
		<input type="text" name="nom" id="nom"/>
		
		<label for="prenom">Prénom</label>
		<input type="text" name="prenom" id="prenom"/>
		
		<label for="adresse">Adresse</label>
		<input type="text" name="adresse" id="adresse"/>
		
		<label for="ville">ville</label>
		<input type="text" name="ville" id="ville"/>
		
		<label for="codePostal">Code Postal</label>
		<input type="text" name="codePostal" id="codePostal"/>
		
		<input type="submit" value="Envoyer"/>
	</form>

</body>
</html>
