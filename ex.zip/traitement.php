<html>
<head>
	<title>Page Title</title>
</head>
<body>

<?php

	if(isset($_POST['nom'])&&isset($_POST['prenom'])&&isset($_POST['adresse'])&&isset($_POST['ville'])&&isset($_POST['codePostal']))
	{
		$nom=(string)$_POST['nom'];
		$prenom=(string)$_POST['prenom'];
		$adresse=(string)$_POST['adresse'];
		$ville=(string)$_POST['ville'];
		$codePostal=(int)$_POST['codePostal'];
		

		echo '<table>';
		echo '<caption>Adresse Client</caption>';
		echo '<thead>';
			echo '<tr>';
				echo '<th>Nom</th>';
				echo '<th>Prénom</th>';
				echo '<th>Adresse</th>';
				echo '<th>Ville</th>';
				echo '<th>Code Postal</th>';
			echo '</tr>';
		echo '</thead>';
		
		echo '<tbody>';
			echo '<tr>';
				echo '<td>'.$nom.'</td>';
				echo '<td>'.$prenom.'</td>';
				echo '<td>'.$adresse.'</td>';
				echo '<td>'.$ville.'</td>';
				echo '<td>'.$codePostal.'</td>';
			echo '</tr>';
		echo '</tbody>';

		
		echo '</table>';

		
	}
	else
	{
		echo '<script type="texte/javascript"> alert(paramètre manquant);</script>';
	}

?>


</body>
</html>
