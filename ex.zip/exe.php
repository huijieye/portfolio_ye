<?php
/*	$fond=$_POST['fond'];
	$text=$_POST['text'];

	setcookie("colorCss",$fond,$text,time()+5184000); //1800=1/2h,5184000=2mois*/

?>

<html>
<head>
	<title>Formulaire</title>
	<meta charset="utf-8"/>
	
</head>
<body>


	<?php

	 session_start();

	 $_session['fond']=$_POST['fond'];
	 $_session['text']=$_POST['text'];
	
	 /* echo '<p style="color:'.$text.';">Accueil</p>';
	  echo '<style type="text/css">body{background:'.$fond.'};';*/

 	  echo '<p style="color:'.$_session['text'].';">Accueil</p>';
	  echo '<style type="text/css">body{background:'.$_session['fond'].'};';
	?>

</body>
</html>
