<html>
<head>
	<title>Formulaire</title>
	<meta charset="utf-8"/>
</head>
<body>

	<form method="POST" action="exe.php">
	
		<h1>Adresse Client</h1>
	
		<label for="fond">Fond</label>
		<input type="color" name="fond" id="fond"/>
		
		<label for="text">Texte</label>
		<input type="color" name="text" id="text"/>
		
		<input type="submit" value="Envoyer"/>
	</form>

</body>
</html>
