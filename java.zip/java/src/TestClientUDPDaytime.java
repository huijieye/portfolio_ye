public class TestClientUDPDaytime
     { public static void main(String[] args)
        { //verifie les arguments de la ligne de commande
          if (args.length !=1)
            { System.out.println("usage : java TestClientUDPDaytime <serveur>");
               System.exit(0);
             }
         try
          {ClientUDP client = new ClientUDP (args[0],13);
         client.envoyerMessage("");
         System.out.println(client.recevoirMessage());
         client.fermer();
      }
      catch(Exception e) {System.out.println(e);} 
     } // end main
   }

