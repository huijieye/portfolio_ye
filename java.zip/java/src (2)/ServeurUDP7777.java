
import java.net.*;

public class ServeurUDP7777 implements ClientServeur{

	private InetAddress adresseIPDistante;
	private int portDistant;
	private DatagramSocket socket;
	
	public ServeurUDP7777() throws Exception
	{
		this.adresseIPDistante=null;
		this.portDistant=0;
		this.socket=new DatagramSocket(7777);
	}
	
	public void envoyerDatas(byte[] datas) throws Exception
	{
		DatagramPacket p;
		p=new DatagramPacket(datas,datas.length,this.adresseIPDistante,this.portDistant);
		this.socket.send(p);
	}
	
	public void envoyerMessage(String message) throws Exception
	{
		byte[] datas= message.getBytes();
		this.envoyerDatas(datas);
	}
	
	public byte[] recevoirDatas() throws Exception
	{
		DatagramPacket p;
		byte[] datas= new byte[1024];
		p=new DatagramPacket(datas,datas.length);
		this.socket.receive(p);
		this.adresseIPDistante=p.getAddress();
		this.portDistant=p.getPort();
		return (p.getData());
	}

	public String recevoirMessage() throws Exception
	{
		return (new String(this.recevoirDatas()));
	}
	
	public void fermer()
	{
		this.socket.close();
	}
	
	public void fonctionner() throws Exception
	{
		boolean actif=true;
		do{
			String message=this.recevoirMessage();
			
			if(message.trim().equals("stop"))
			{
				actif=false;
				this.envoyerMessage("le serveur est arrete");
				this.fermer();
			}
			else
			{
				this.envoyerMessage(message);
			}
		}while(actif==true);
	}
	
}
