public class LancerServeurUDP7777
     { public static void main(String[] args)
       {    try
            {ServeurUDP7777 serveur= new ServeurUDP7777();
             serveur.fonctionner();
           }	 
            catch(Exception e) {} 
          } // end main
   }
