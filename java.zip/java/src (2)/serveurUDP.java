
import java.net.*;

public class ServeurUDP implements ClientServeur{

	private InetAddress adresseIPDistante;
	private int portDistant;
	private DatagramSocket socket;
	
	public ServeurUDP(int port)
	{
		this.adresseIPDistante=null;
		this.portDistant=port;
		this.socket=new DatagramSocket();
	}
	
	public void envoyerDatas(byte[] datas) throws Exception
	{
		DatagramPacket p;
		p=new DatagramPacket(datas,datas.length,this.adresseIPDistante,this.portDistant);
		this.socket.send(p);
	}
	
	public void envoyerMessage(String message) throws Exception
	{
		byte[] datas= message.getBytes();
		this.envoyerDatas(datas);
	}
	
	public void fermer()
	{
		this.socket.close();
	}
	
	abstract void fonctionner() throws Exception
	{
		
	}
	
}
