import java.io.*;
public class TestClientUDP7777
  { public static void main(String[] args)
     {//v�rifie les arguments de la ligne de commande
        if (args.length !=2)
           { System.out.println("usage : java TestClientUDPEcho <serveur> <message>");
              System.exit(0);
            }
        try
         { ClientUDP client1 = new ClientUDP(args[0],7777);
           client1.envoyerMessage(args[1]);
           System.out.println(client1.recevoirMessage());
           client1.fermer();
        /*   ClientUDP client2 = new ClientUDP();
           client2.envoyerMessage(args[1],args[0],7777);
           System.out.println(client2.recevoirMessage());
           client2.fermer();*/
         }
      catch(Exception e) {System.out.println(e);} 
     } // end main
   }
