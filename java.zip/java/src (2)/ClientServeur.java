
public interface ClientServeur {
	
	public void envoyerDatas(byte[] datas) throws Exception;
	
	public byte[] recevoirDatas() throws Exception;

}
