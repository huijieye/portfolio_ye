

import java.net.*;

public class ClientUDP implements ClientServeur 
{
	private InetAddress adresseIPDistante;
	private int portDistant;
	private DatagramSocket socket;
	
	public ClientUDP() throws Exception
	{
		this.adresseIPDistante=null;
		this.portDistant=0;
		this.socket=new DatagramSocket();
				
	}
	
	public ClientUDP(String nomServeur, int portServeur) throws Exception
	{
		this.adresseIPDistante=InetAddress.getByName(nomServeur);
		this.portDistant=portServeur;
		this.socket=new DatagramSocket();
	}
	
	public void envoyerDatas(byte[] datas) throws Exception
	{
		DatagramPacket p;
		p=new DatagramPacket(datas,datas.length,this.adresseIPDistante,this.portDistant);
		this.socket.send(p);
	}

	public void envoyerDatas(byte[] datas,InetAddress adresseIPDistante, int portDistant) throws Exception
	{
		DatagramPacket p;
		p=new DatagramPacket(datas,datas.length,adresseIPDistante,portDistant);
		this.socket.send(p);
	}
	
	public void envoyerMessage(String message) throws Exception
	{
		byte[] datas= message.getBytes();
		this.envoyerDatas(datas);
	}
	
	public void envoyerMessage(String message,String adresseIPDistante, int portDistant) throws Exception
	{
		byte[] datas= message.getBytes();
		this.envoyerDatas(datas,InetAddress.getByName(adresseIPDistante),portDistant);
	}
	
	public void fermer()
	{
		this.socket.close();
	}
	
	public byte[] recevoirDatas() throws Exception
	{
		DatagramPacket p;
		byte[] datas= new byte[1024];
		p=new DatagramPacket(datas,datas.length);
		this.socket.receive(p);
		return (p.getData());
	}
	
	public String recevoirMessage() throws Exception
	{
		return (new String(this.recevoirDatas()));
	}
	
}
