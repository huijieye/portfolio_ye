
import java.net.*;
import java.io.*;

public class ServeurTCP implements ClientServeur{

	private ServerSocket socket;
	private PrintWriter out;
	private BufferedReader in;
	
	public ServeurTCP() throws Exception
	{
		this.out=new PrintWriter(this.socket.getOu);
		this.in=new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
		this.socket=new ServerSocket();
	}
	
	public ServeurTCP(String nomServeur, int portServeur) throws Exception
	{
		this.socket=new Socket(nomServeur,portServeur);
	}
	
	public void envoyerMessage(String message,InetAddress adresseServeur, int portServeur) throws Exception
	{
		this.socket=new Socket(adresseServeur,portServeur);
		this.out.println(message);
		this.out.flush();
	}
	
	public void envoyerMessage(String message) throws Exception
	{
		this.out.println(message);
		this.out.flush();
	}
	
	public void recevoirMessage() throws Exception
	{
		System.out.println(in.readLine());
		
	}
	
	public void fermer() throws Exception
	{
		this.out.close();
		this.in.close();
		this.socket.close();
	}
	
	
}
