
public class TestClientTCPWeb
  { public static void main(String[] args)
     {//v�rifie les arguments de la ligne de commande
      if (args.length !=2)
       { System.out.println("usage : java TestClientTCPEcho <serveur> <message>");
         System.exit(0);
       }
      try
        {ClientTCPWeb client = new ClientTCPWeb(args[0]);
         client.envoyerMessage(args[1]);
         System.out.println(client.recevoirMessage()); 
         /*client.envoyerMessage("bis : "+args[1]);
         System.out.println(client.recevoirMessage());*/
         client.fermer();
      }
      catch(Exception e) {System.out.println(e);} 
     } // end main
   }

