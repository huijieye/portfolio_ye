
public interface ClientServeur {
	
		public void envoyerMessage(String message) throws Exception;
		
		public String recevoirMessage() throws Exception;

}
