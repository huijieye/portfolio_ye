
import java.net.*;
import java.io.*;

public class ClientTCP implements ClientServeur{

	private Socket socket;
	private PrintWriter out;
	private BufferedReader in;
	
	
	public ClientTCP(String nomServeur, int portServeur) throws Exception
	{
		this.socket=new Socket(InetAddress.getByName(nomServeur),portServeur);
		this.out=new PrintWriter(this.socket.getOutputStream());
		this.in=new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
	}
	
	
	public void envoyerMessage(String message) throws Exception
	{
		this.out.println(message);
		this.out.flush();
	}
	
	public String recevoirMessage() throws Exception
	{
		String rep="";
		while(!in.ready()) // boucle d'attente
		{}
		
        do
		 { rep=rep + in.readLine();
		 }while(in.ready());
		return rep;
	}
	
	public void fermer() throws Exception
	{
		this.out.close();
		this.in.close();
		this.socket.close();
	}
	
	
}
