
public class ClientTCPWeb extends ClientTCP{
	
	public ClientTCPWeb(String nomServeur) throws Exception
	{
		super(nomServeur,80);
	}

}
