public class TestClientTCPDaytime
     { public static void main(String[] args)
        {//v�rifie les arguments de la ligne de commande
         if (args.length !=1)
           { System.out.println("usage : java TestClientTCPDaytime <serveur>");
             System.exit(0);
           }
         try
           {ClientTCP client = new ClientTCP(args[0],13);
            client.envoyerMessage("");// n'importe quel message fait l'affaire
            System.out.println(client.recevoirMessage());
            client.fermer();
      }
      catch(Exception e) {System.out.println(e);} 
     } // end main
   }


