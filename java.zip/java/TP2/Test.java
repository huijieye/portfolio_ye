import java.util.*;
public class Test
{
   public static void main(String[] args)
   {
	try{
		Hub h= new Hub("hub.txt");
	//Routeur r =new Routeur("r","192.168.1.2","00:01:01:01:01:01","192.168.2.2","00:22:22:22:22:22",h,h);
	//r.init();
	//System.out.println(h);
	Machine a=h.elementAt(0);
	Machine b=h.elementAt(1);
	//DonneesARP arpRequest=new DonneesARP(1,a.getAdresseMAC(),a.getAdresseIP(),b.getAdresseMAC(),b.getAdresseIP());
	//DonneesICMP icmp1=new DonneesICMP(8,0);
	//DonneesIP ip1=new DonneesIP(4,01,a.getAdresseIP(),b.getAdresseIP(),icmp1);
	a.envoyerICMP(b.getAdresseIP(),b.getAdresseMAC(),8,0);
	//DonneesARP arpReply=new DonneesARP(2,b.getAdresseMAC(),b.getAdresseIP(),a.getAdresseMAC(),b.getAdresseIP());
	//DonneesICMP icmp2=new DonneesICMP(0,0);
	//DonneesIP ip2=new DonneesIP(4,01,b.getAdresseIP(),a.getAdresseIP(),icmp2);
	//b.emettreTrame(a.getAdresseMAC(),"08000",ip2);
	String c=a.toStringComplet();
	String d=b.toStringComplet();
	System.out.println(c);
	System.out.println(d);
	//Machine p =new Machine("p","192.168.0.2","00:00:00:00:00:00",h);
	
	//p.connecterAuHub(h);
	//r.connecterAuHub(h);
	//h.enregistrerTexte("hub.txt");
	//Machine p=new Machine("truc","192.168.0","00:00:00:00:00:00");
	//Machine l=new Machine("tu","192.168.0.9","1");
	}

	catch(Exception e)
	{
	System.out.println(e);
	}
   }
}
