// tp 3
public class Trame 
   { private String DA;
      private String SA;
		private String EType;
      private Donnees donnees;
   
      public Trame(String DA,String SA,String EType,Donnees donnees)
      { this.DA  = DA;
        this.SA  = SA;
        this.EType  = EType;
        this.donnees = donnees;
      }
   
      public String getDA() {return(this.DA);}
      public String getSA() {return(this.SA);}
      public String getEType() {return(this.EType);}
      public Donnees getDonnees() {return(this.donnees);}
   
      public String toString() { 
         return(this.DA+";"+this.SA+";"+this.EType+";"+this.donnees );}
   
   }



