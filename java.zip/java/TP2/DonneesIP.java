// AdresseIP
public class DonneesIP  extends Donnees
   {private int version;
	 private int protocole;
    private String SIP;  // source IP
	 private String TIP;  // target IP
 	 
	 public DonneesIP(int version, int protocole,String SIP, String TIP, Donnees donneesNiveauSuperieur)  throws Exception
	   {super(donneesNiveauSuperieur);
       Protocoles.verifierIPMachine(SIP);
       Protocoles.verifierIPMachine(TIP);
       this.version = version;
		 this.protocole = protocole;
	    this.SIP = SIP;
	    this.TIP = TIP;
		}
		
	 public int getVersion()
	   {return(this.version);}	
	
	 public int getProtocole()
	   {return(this.protocole);}	

	 public String getSIP()
	   {return(this.SIP);}	
	 
	 public String getTIP()
	   {return(this.TIP);}	
   
    public String toString()
	    { return(this.version+";"+this.protocole+";"+this.SIP+";"+this.TIP+";"+this.getDonneesNiveauSuperieur());
		 }
  }