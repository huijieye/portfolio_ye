// tp 3
import java.util.*;

public class Routeur extends Machine
 { private String adresseIP2;
   private String adresseMAC2;
   private Hub hub2;

   public Routeur()
	  {super();
	   this.adresseIP2="";
      this.adresseMAC2="";
	  }
	
	public Routeur(String nom, String adresseIP, String adresseMAC, String adresseIP2, String adresseMAC2, Hub hub, Hub hub2) throws Exception  
	{super( nom,adresseIP, adresseMAC,hub);
	Protocoles.verifierIPMachine(adresseIP2);
    this.adresseIP2 = adresseIP2;
	Protocoles.verifierMac(adresseMAC);
	 this.adresseMAC2 = adresseMAC2;
    this.setHub2(hub2);
	}
	
  public Routeur(String nom, String adresseIP, String adresseMAC, String adresseIP2, String adresseMAC2) throws Exception 
	{this( nom,adresseIP, adresseMAC,adresseIP2,adresseMAC2,null,null);
	}
	
	public Routeur(Machine m, String adresseIP2, String adresseMAC2, Hub hub2) throws Exception 
	 {super(m);
	Protocoles.verifierIPMachine(adresseIP2);
    this.adresseIP2 = adresseIP2;
        Protocoles.verifierMac(adresseMAC2);
         this.adresseMAC2 = adresseMAC2;
     this.setHub2(hub2);
 }

   public Routeur( Routeur r) throws Exception 
	 {super(r);
	  this.adresseIP2 = r.adresseIP2;
	  this.adresseMAC2 = r.adresseMAC2;
     this.setHub2(r.hub2);
    }

    public void init() throws Exception
	   { super.init();
		  Scanner sc = new Scanner(System.in);
	boolean ok=false;
        do {
			try{
                System.out.print("adresse IP deuxieme carte ? : ");
                String IP2=sc.nextLine();
                Protocoles.verifierIPMachine(IP2);
                this.adresseIP2=IP2;
                ok=true;
            }

			catch(Exception e){
                System.out.println(e);
            }
        }while(!ok);

        ok=false;

        do{
            try{
                System.out.print("adresse MAC deuxieme carte ? : ");
                String MAC2=sc.nextLine();
                Protocoles.verifierMac(MAC2);
                this.adresseMAC2=MAC2;
		ok=true;
		}
	    catch(Exception e) {
		System.out.println(e);
		}
	}while(!ok);
	}	

    public String getAdresseIP2() {return(this.adresseIP2);}
    public String getAdresseMAC2() {return(this.adresseMAC2);}
    public void setHub2(Hub hub){this.hub2 = hub;} 

   /**
 	 retourne un tableau de quatre entiers, chacun de ces entiers correspondant
	 � un nombre de la deuxi�me adresse IP du routeur
  **/

    public int[] getTableauIP2() 
	   { 
		   Machine p=null;
	     try 
	       { p=new Machine("",this.adresseIP2,this.adresseMAC2);
	        }
	      catch(Exception e){}
		   return(p.getTableauIP());
		}

	/**
	retourne 'A', 'B', ou 'C' selon que la deuxi�me adresse IP du routeur 
	est de classe A, B ou C.
	**/

     public char getClasse2() 
	  { 
		  Machine p=null;
	     try 
	       { p=new Machine("",this.adresseIP2,this.adresseMAC2);
	        }
	      catch(Exception e){}
		  return(p.getClasse());
 	  }

	   public String getIPReseau2()  throws Exception
		 {
			 Machine p=null;
	     try 
	       { p=new Machine("",this.adresseIP2,this.adresseMAC2);
	        }
	      catch(Exception e){}
			 return(p.getIPReseau());
		 }

	/** permet de savoir si le routeur fournissant la m�thode 
     appartient au m�me r�seau que la machine pass�e en param�tre
	**/    
	 
   public boolean estCompatible(Machine m) 
	  {//return(super.estCompatible(m) || new Machine("",this.adresseIP2,this.adresseMAC2).estCompatible(m));
	     Machine p=null;
	     try 
	       { p=new Machine("",this.adresseIP2,this.adresseMAC2);
	        }
	      catch(Exception e){}
	      
	      return(p.estCompatible(m));
  
	}

   public String toString()
      {return (super.toString()+ ";" + this.adresseIP2 + ";" + this.adresseMAC2);}
  
    public boolean equals (Object o)    
      { if (!(o instanceof Routeur))
          return false;
		  Routeur r = (Routeur)o; 
		  return(super.equals(o) && this.adresseIP2.equals( r.adresseIP2)&& this.adresseMAC2.equals( r.adresseMAC2));
		} 
	
	/**
	renvoie -1 si le routeur a la plus petite des quatre adresses IP,
	1 si c'est le routeur re�u en param�tre qui a la plus petite des quatre adresses IP,
	et 0 si les quatre adresses IP sont �gales
	**/
	
	public int compareTo(Routeur r) throws Exception
	  {int tabMin1[]; 
	   int tabMin2[]; 
		int tab1[] = this.getTableauIP();
	   int tab2[] = this.getTableauIP2();
	   int tab3[] = r.getTableauIP();
	   int tab4[] = r.getTableauIP2();
      int i=0;
		while((i<4) && (tab1[i]==tab2[i])) // recherche plus petite IP de this
			  {i++;}
  	  if ((i==4) || (tab1[i]< tab2[i]))
		  tabMin1 = tab1;
		 else
		  tabMin1 = tab2; 
	   i=0;
		while((i<4) && (tab3[i]==tab4[i])) // recherche plus petite IP de r
		  {i++;}
		if ((i==4) || (tab3[i]< tab4[i]))
		  tabMin2 = tab3;
		 else
		  tabMin2 = tab4; 
		  // comparaison des deux tabMin
	    i=0;
		 while((i<4) && (tabMin1[i]==tabMin2[i]))
 		  {i++;}
       if (i==4)
		   return(0);
	   if (tabMin1[i]< tabMin2[i])
 		 return(-1);  
		else
		return(1);
	  }
}// end class
 
