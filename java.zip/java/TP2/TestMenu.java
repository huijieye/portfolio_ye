// tp 3
import java.util.Scanner;

public class TestMenu
  { public static void main (String[] args)
      { Hub hub = new Hub(5);
		  // Hub hub = new Switch(5);
	 	  Machine [] tabMachines= new Machine[5];
        int reponse,position;
        int nbMachines=0; // nombre de machines dans le tableau du main
   	  Scanner sc = new Scanner(System.in);
        System.out.println("1/ initialiser le hub vide et utiliser des machines pr�d�finies");
        System.out.println("2/ initialiser le hub � partir de la m�thode init");
		  do
          {System.out.print("votre choix ? : ");
			  reponse=sc.nextInt();
          } while ((reponse<1) || (reponse>2));
         if (reponse==1)
           {// 5 machines pr�d�finies
           try{
            tabMachines[0] = new Machine("menelas","192.168.0.2","00:00:00:00:00:00",hub);
            tabMachines[1] = new Machine("polux","192.168.0.3","11:11:11:11:11:11",hub);
            tabMachines[2] = new Machine("ajax","192.168.0.4","22:22:22:22:22:22",hub);
            tabMachines[3] = new Machine("enee","192.168.0.5","33:33:33:33:33:33",hub);
            tabMachines[4] = new Machine("cresus","192.168.0.6","44:44:44:44:44:44",hub);
            nbMachines = 5;
            
            
            
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
           }
         else
           {
			   try{
				  hub.init();
			  }
			  catch(Exception e)
			  {
				  System.out.println(e);
				}
            
           }
         do
           {System.out.println("1/ tester si le hub est vide ");
            System.out.println("2/ tester si le hub est plein ");
            System.out.println("3/ tester si une machine donnee est branchee sur le hub");
            System.out.println("4/ brancher une machine a partir de la classe Machine");
            System.out.println("5/ brancher une machine a partir de la classe Hub");
            System.out.println("6/ creer une nouvelle machine et la connecter a partir de la classe Machine");
            System.out.println("7/ debrancher une machine a partir de la classe Machine");
            System.out.println("8/ debrancher une machine a partir de la classe Hub");
            System.out.println("9/ debrancher une machine d'un port precis du hub");
            System.out.println("10/ �mettre une trame sur le r�seau");
            System.out.println("11/ afficher le contenu du hub ");
            System.out.println("0/ terminer : ");
            do 
              { System.out.print("votre choix ? : ");
				    reponse=sc.nextInt();
              } while ((reponse<0) || (reponse>11));
            switch (reponse)
              { case 1 : if (hub.estVide())
                            System.out.println("hub vide");
                         else
                            System.out.println("hub non vide");
                         break;
                case 2 : if (hub.estPlein())
                           System.out.println("hub plein");
                         else
                           System.out.println("hub non plein");
                         break;
        		    case 3 :do
			                {System.out.print("position de la machine dans le tableau local ? : ");
			                 position=sc.nextInt();
				             }while((position<0) || (position>nbMachines-1)); 
                        if (hub.contains(tabMachines[position]))
							    System.out.println("la machine est branch�e sur le hub");
								else 
     						    System.out.println("la machine n'est pas branch�e sur le hub");
	                    break;
         		    case 4 :do
			                {System.out.print("position de la machine dans le tableau local ? : ");
			                 position=sc.nextInt();
				             }while((position<0) || (position>nbMachines-1)); 
							try{
								tabMachines[position].connecterAuHub(hub);
							    System.out.println("la connexion a r�ussi");
							}
							catch(Exception e){ 
								System.out.println(e);
     						    System.out.println("la connexion a �chou�");
							}
	                    break;
                   case 5 :do
			                {System.out.print("position de la machine dans le tableau local ? : ");
			                 position=sc.nextInt();
				             }while((position<0) || (position>nbMachines-1)); 
							try{
							hub.connecterMachine(tabMachines[position]);
							    System.out.println("la connexion a r�ussi");
							}
							catch(Exception e){ 
								System.out.println(e);
     						    System.out.println("la connexion a �chou�");
							}
	                    break;
                    case 6 : if (nbMachines==tabMachines.length)
                               System.out.println("tableau plein");
                             else
                               {Machine m = new Machine();
                                
                                try{
									m.init();
									m.connecterAuHub(hub);
							        System.out.println("la connexion a r�ussi");
                                   tabMachines[nbMachines]=m;
                                   nbMachines++; 
                                  }
								 catch(Exception e)
								 {
										System.out.println(e);
     						             System.out.println("la connexion a �chou�");
     						     }

                               }
                             break;
                    case 7 : do
			                {System.out.print("position de la machine dans le tableau local ? : ");
			                 position=sc.nextInt();
				             }while((position<0) || (position>nbMachines-1)); 
							try{
								tabMachines[position].debrancherDuHub();
							    System.out.println("la machine a �t� d�branch�e");
							}
							catch(Exception e){
								System.out.println(e);
     						    System.out.println("probl�me");
							}
                       break;
                  case 8 : do
			                {System.out.print("position de la machine dans le tableau local ? : ");
			                 position=sc.nextInt();
				             }while((position<0) || (position>nbMachines-1)); 
                         try{
							 hub.debrancherMachine(tabMachines[position]);
							        System.out.println("la machine a �t� d�branch�e");
							}
							catch(Exception e){
								System.out.println(e);
     						        System.out.println("probl�me");
     						       }
                         break;
                         
					   case 9: System.out.print("position du port ? : ");
                          position=sc.nextInt();
		                    try{
								hub.debrancherMachine(position);
							       System.out.println("la machine a �t� d�branch�e");
							}
							catch(Exception e)
							{
									System.out.println(e);
     						       System.out.println("probl�me");
     						      }
                          break;
	  			      case 10: System.out.print("num�ro de port de la machine emettrice : ");
		 		              position=sc.nextInt();
                         try{
							 hub.estOccupe(position);
							 System.out.print("adresse MAC poste destination : ");
				              String adresseMAC = sc.next();
				              System.out.print("message : ");
				              String message = sc.next();
							     Donnees donnees = new Donnees(message);
					           hub.elementAt(position).emettreTrame(adresseMAC,"etype",donnees);
					          }
								
							  catch(Exception e){
								  System.out.println(e); 
							    System.out.println("aucune machine connect�e sur ce port");
							}
 				          break;
             case 11:  System.out.println(hub);
					       break;
           }  // end hub
         } while (reponse!=0);     
		 }  // end main
   } // end class
