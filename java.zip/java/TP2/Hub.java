// tp 4
import java.util.*;
import java.io.*;
public class Hub
  {private  ArrayList <Machine> listeMachines;
   private int nbMachines;

   public Hub(int taille)
	 {this.listeMachines =new  ArrayList<Machine>();
 	  for(int i=0;i<taille;i++)
	  this.listeMachines.add(null);
    this.nbMachines = 0;
	 }

  	public int size(){return(this.listeMachines.size());}
	public int getNbMachines(){return(this.nbMachines);}
	public ArrayList <Machine> getListeMachines(){return(this.listeMachines);}

	public boolean estVide(){return(this.nbMachines == 0);}
	public boolean estPlein(){return(this.nbMachines == this.size());}

  /**
	  retourne la machine branch�e sur le port num�ro port
	**/
 	public Machine elementAt(int port) 
     {if ((port<0) ||(port>=this.nbMachines))
       return(null);
      else
       return (this.listeMachines.get(port));
     }

  public boolean estOccupe(int port) throws Exception
{return(this.elementAt(port) != null);} 

     /** branche la machine m sur le port port sans pr�caution
   **/
   // pas besoin de v�rifier le num�ro de port parce que les m�thodes
   // qui utilisent setMachine font la v�rification 
   // m�thode utile pour passer de l'impl�mentation avec tableau � l'impl�mentation
   // avec ArrayList
   // la mettre en public pour pouvoir la tester ; private ensuite
   private void setMachine(Machine m, int port) throws Exception
     {this.listeMachines.set(port,m);}

	 /**
	  initialisation interactive ; on peut brancher des machines ou des routeurs ; 
	  l'occupation des ports doit �tre continue
	  **/
   public void init() throws Exception
      { int reponse;
		  String encore;
        Machine m;
		  Scanner sc = new Scanner(System.in);
		  do
		   { do
			   {System.out.print("1 : machine / 2 : routeur ");
			    reponse=sc.nextInt();
				}while((reponse<1) || (reponse>2)); 
			  if (reponse==1) 
               m=new Machine();
            else 
               m=new Routeur();
           m.init();
           this.setMachine(m,this.nbMachines);
			  m.setHub(this);
           this.nbMachines++;
           System.out.print("encore ? : ");
			  encore = sc.next();
         }while(encore.equals("o") && !this.estPlein());
      }

       public String toString()
		  {String s = "";
		  //toString de chaque machine ou routeur
         for(int i=0;i<this.nbMachines;i++)
            { 
				if(i==0)
				{
					s=s+this.elementAt(i);
				}
				else
				{
				s=s+"\n"+this.elementAt(i);
				}
            }
			 return(s);
			}
  
 /**
	  retourne le num�ro du port sur lequel la machine m est branch�e ;
	  retourne -1 si la machine m n'est pas branch�e
	**/
    public int positionMachine(Machine m)
     	 {  return(this.listeMachines.lastIndexOf(m));
		 }
 
  	/**
	  retourne true si la machine m est branch�e au hub et false sinon
	**/
   public boolean contains(Machine m)
		 { return (this.listeMachines.contains(m));
		 }

	 /**
	  on ne doit pas brancher deux fois la m�me machine
	  on branche la machine sur le premier port libre 
	  **/
  	 public void connecterMachine(Machine m) throws Exception
      { if(this.estPlein()|| this.contains(m))
  		    throw new Exception("Le hub est plein ou contient deja la machine");
	     this.setMachine(m,this.nbMachines);
		  m.setHub(this);
    	  this.nbMachines++;
	  }

    public boolean connecterRouteur(Routeur r,int eth) throws Exception
      { if(this.estPlein()|| this.contains(r))
  		    return (false);
	     this.setMachine(r,this.nbMachines);
        if (eth==0)
		    r.setHub(this);
        else  
  		    r.setHub2(this);
   	  this.nbMachines++;
		  return(true);
	  } 

  /**
	  on d�branche la machine branch�e sur le port port (si celui-ci est occup�)
	   on la remplace par la derni�re et on met cette derni�re � null
  **/
  
     public void debrancherMachine(int port) throws Exception
      { if (this.estOccupe(port))
			  {this.elementAt(port).setHub(null);
            Machine derniere = this.elementAt(this.nbMachines-1);    
            this.setMachine(derniere,port);
	   	   this.setMachine(null,this.nbMachines-1);
            this.nbMachines--;
			  }
         else  
		     throw new Exception("La machien n'est pas connectee");
      }
 
  public void debrancherRouteur(int port,int eth) throws Exception
      { if (this.estOccupe(port))
			  {if (eth==0)
              this.elementAt(port).setHub(null);// la machine n'est plus reli�e au hub
            else  
             ((Routeur)this.elementAt(port)).setHub2(null);// la machine n'est plus reli�e au hub
            Machine derniere = this.elementAt(this.nbMachines-1);    
            this.setMachine(derniere,port); // on branche la derni�re machine 
														  // � la place de celle qu'on vient de d�brancher	
			   this.setMachine(null,this.nbMachines-1);
            this.nbMachines--;
			  }
		  else
           throw new Exception("Le rouiteur n'est pas branche au hub");
      }
  
     
  /**
	  on d�branche la machine  m (si elle est branch�e)
     on la remplace par la derni�re et on met cette derni�re � null
	  **/
     public void debrancherMachine(Machine m) throws Exception
      { this.debrancherMachine(this.positionMachine(m));
      }
  
     public void debrancherRouteur(Routeur r,int eth) throws Exception
      { this.debrancherRouteur(this.positionMachine(r),eth);
      }
 
 /**
   le hub �met la trame vers toutes les machines connect�es 
	sauf celle qui a �mis la trame 
 **/
     public void emettreTrame(Machine machineEmettrice, Trame t)
	    {	 for(int i=0;i<this.nbMachines;i++)
		   { if (this.elementAt(i) != machineEmettrice) 
			    this.elementAt(i).recevoirTrame(t);
			}
		 }
       
        
   public String toStringComplet() 
		  {String s = "taille du hub : " + this.size();
		  //toString de chaque machine ou routeur
         for(int i=0;i<this.nbMachines;i++)
            { s=s+"\n"+this.elementAt(i).toStringComplet();
            }
  			 return(s);
			}


	public void enregistrerTexte(String nomFichier) throws Exception
	{
		PrintWriter pw= new PrintWriter(nomFichier);
		pw.println(this.size());
		pw.print(this);
		pw.close();
	}

	public Hub(String nomFichier) throws Exception
	{
		FileReader f=new FileReader(nomFichier);
		BufferedReader bIn= new BufferedReader(f);
		String ligne = bIn.readLine();
		int taille=Integer.parseInt(ligne);
		this.listeMachines =new  ArrayList<Machine>();
		for(int i=0;i<taille;i++)
		this.listeMachines.add(null);
		this.nbMachines = 0;
		ligne=bIn.readLine();
		while(ligne!=null)
		{
			StringTokenizer st=new StringTokenizer(ligne,";");
			int i=st.countTokens();
			if(i==3)
			{
					new Machine(st.nextToken(),st.nextToken(),st.nextToken(),this);
			}
			
			else
			{
					//this.setMachine(new Routeur(st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(),this,null),this.nbMachines-1);
					new Routeur(st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(),this,null);		
			}
			//System.out.println(this.nbMachines);
			//connectes=connectes+1;
			ligne=bIn.readLine();
		}
		bIn.close();
		f.close();
	}
 }//fin classe Hub
