// AdresseIP
public abstract class Donnees 
   { private Donnees donneesNiveauSuperieur;
	
	  public Donnees()
	    {this.donneesNiveauSuperieur = null;
		 }
	  
	 public Donnees(Donnees donneesNiveauSuperieur)
	    {this.donneesNiveauSuperieur = donneesNiveauSuperieur;
		 }

	  public  Donnees getDonneesNiveauSuperieur(){return(donneesNiveauSuperieur);}
	  
	 public boolean equals(Object o)
       { if (!(o instanceof Donnees)) 
            return false;
			Donnees d = (Donnees)o;	
         return(this.donneesNiveauSuperieur.equals(d.donneesNiveauSuperieur));
       }
	}
