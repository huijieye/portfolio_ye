// AdresseIP
public class DonneesUDP  extends Donnees
   {private int portSource;
	 private int portDestination;
 	 
	 public DonneesUDP(int portSource, int portDestination, Donnees donneesNiveausup)
	   {super(donneesNiveausup);
       this.portSource = portSource;
	    this.portDestination = portDestination;
		}
		
	 public int getPortSource()
	   {return(this.portSource);}	
	
	 public int getPortDestination()
	   {return(this.portDestination);}	

   
		
     public String toString()
	    { return(this.portSource+";"+this.portDestination+";"+this.getDonneesNiveauSuperieur());
		 }
  }