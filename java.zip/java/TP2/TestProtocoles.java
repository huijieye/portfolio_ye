import java.util.*;

public class TestProtocoles
{ 
