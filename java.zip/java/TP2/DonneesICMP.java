// AdresseIP
public class DonneesICMP extends Donnees
   {private int type;
    private int code;
	 
	 public DonneesICMP(int type, int code)
	   {super();
       this.type = type;
		 this.code = code;
		}
		
	 public int getType()
	   {return(this.type);}	

	 public int getCode()
	   {return(this.code);}	

	     public String toString()
	    { return(this.type+";"+this.code);
		 }
 
 }