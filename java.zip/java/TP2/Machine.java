// tp 4
import java.util.*;
import java.text.*;
import java.io.*;
//import Protocoles;

public class Machine
  { private String nom;
    private String adresseIP;
    private String adresseMAC;
    private Hub hub;
    private ArrayList <Trame> tramesRecues;
    private ArrayList <Trame> tramesEnvoyees;

   public Machine (String nom, String adresseIP, String adresseMAC, Hub hub) throws Exception
      { this.nom = nom;
	Protocoles.verifierIPMachine(adresseIP);
        this.adresseIP = adresseIP;
	Protocoles.verifierMac(adresseMAC);
        this.adresseMAC = adresseMAC;
	     if (hub != null)
		     hub.connecterMachine(this);
	 	  this.tramesRecues = new ArrayList <Trame>();
   	  this.tramesEnvoyees = new ArrayList <Trame>();
     }

	 public Machine ()
      { this.nom="";
        this.adresseIP="";
	this.adresseMAC="";
      }

    public Machine (String nom, String adresseIP, String adresseMAC) throws Exception
      { this(nom,adresseIP,adresseMAC,null);
      }

	  public Machine ( Machine m) throws Exception
      {this(m.nom,m.adresseIP,m.adresseMAC,m.hub);      }

	  public void init() throws Exception
	   { Scanner sc = new Scanner(System.in);
		  System.out.print("nom ? : ");
        this.nom=sc.nextLine();
	boolean ok=false;
	do {
    	  try{
		System.out.print("adresse IP ? : ");
		String IP=sc.nextLine();
		Protocoles.verifierIPMachine(IP);
        	this.adresseIP=IP;
		ok=true;
	    }

	catch(Exception e){
		System.out.println(e);
	    }
	}while(!ok);

	ok=false;

	do{
	    try{
		System.out.print("adresse MAC ? : ");
        	String MAC=sc.nextLine();
        	Protocoles.verifierMac(MAC);
        	this.adresseMAC=MAC;
		ok=true;
	    }
	    catch(Exception e){
		System.out.println(e);
		}
	}while(!ok);

      }


	 public String getNom(){return(this.nom); }
    public String getAdresseIP() {return(this.adresseIP);}
    public String getAdresseMAC() {return(this.adresseMAC);}
    public void setHub(Hub hub){this.hub = hub;}
    public boolean estConnectee() { return(this.hub !=null);}

   /**
	retourne un tableau de quatre entiers, chacun de ces entiers correspondant
	� un nombre de l'adresse IP de la machine
  **/
    public int[] getTableauIP()
	   {int tab[] = new int[4];
		 StringTokenizer st = new StringTokenizer(this.adresseIP,".");
       for(int i=0;i<4;i++)
		   {tab[i] = Integer.parseInt(st.nextToken());
			}
		 return(tab);
		}

	/**
	retourne 'A', 'B', ou 'C' selon que l'adresse IP de la machine 
	est de classe A, B ou C.
	**/

   public char getClasse()
	  { int tab[] = this.getTableauIP();
       int premier = tab[0];
		 if  (premier<127)
         return('A');
       if  ((premier>127)&&(premier<192))
         return('B');
       return('C');
 	  }

   /**
	  calcule l'IP r�seau � partir de l'IP de la machine
	**/
   public String getIPReseau()
      { String adresseIPReseau = "";
		  char classe = this.getClasse(); 
		  StringTokenizer st = new StringTokenizer(this.adresseIP,".");
        switch (classe)
		   { case 'A':  adresseIPReseau = st.nextToken()+".0.0.0";
			             break;    
		     case 'B':  adresseIPReseau = st.nextToken()+"."+st.nextToken()+".0.0"; 
			             break;
           case 'C':  adresseIPReseau = st.nextToken()+"."+st.nextToken()+"."+st.nextToken()+".0"; 
			             break;
			}
   	return(adresseIPReseau);
     } 
 
 /** permet de savoir si la machine fournissant la m�thode 
     appartient au m�me r�seau que la machine pass�e en param�tre
	**/    
	public boolean estCompatible(Machine m)
	  {return(this.getIPReseau().equals(m.getIPReseau()));
	  }
	
   public String toString()
      {return (new String(this.nom + ";" + this.adresseIP + ";" + this.adresseMAC));}
 
   public String toStringComplet()
	  {String s ="nom : " + this.nom + "\n";
	   s = s + "adresse IP : " + this.adresseIP + "\n";
	   s = s + "adresse Mac : " + this.getAdresseMAC() + "\n";
		s = s +"trames re�ues : " + this.tramesRecues + "\n";
		s = s +"trames envoy�es : " + this.tramesEnvoyees+ "\n";
   	return(s);
  	  } 

   
	 public boolean equals(Object o) 
       { if (!(o instanceof Machine)) 
            return false;
			Machine m = (Machine)o;
         return(this.nom.equals(m.nom) && this.adresseIP.equals(m.adresseIP) && this.adresseMAC.equals(m.adresseMAC));
       }

	/**
	renvoie -1 si la machine a une adresse IP plus "petite" 
	que celle de la machine pass�e en param�tre ,
	1 si elle est plus  "grande" et 0 si les deux machines ont la m�me adresse IP
   **/
	
	public int compareTo(Machine m)
	  {int tab1[] = this.getTableauIP();
	   int tab2[] = m.getTableauIP();
	   int i=0;
		while((i<4) && tab1[i]== tab2[i])
		  {i++;}
		if (i==4)
		  return(0);
		if (tab1[i]< tab2[i])
		 return(-1);  
		return(1);
	  }


 /**
  connecte la machine au hub pass� en param�tre
 **/
 	 	public void connecterAuHub(Hub hub) throws Exception
	   { if (hub.contains(this))
		   throw new Exception("La machine est déjà connectée au hub");;
	     this.debrancherDuHub();
        //return (hub.connecterMachine(this));
      }

	/**
	 d�branche la machine du hub auquel elle est branch�e
	**/
  public void debrancherDuHub() throws Exception
    {if (this.estConnectee())
      this.hub.debrancherMachine(this);
	  else
	   throw new Exception("La machine n'est pas connecte au hub");
	 }

 /**
	 la machine fabrique la trame t � partir des donnees puis demande au hub auquel 
	 elle est branch�e d'�mettre la trame vers les autres machines connect�es au hub
	 la trame est rajout�e � la liste des trames envoy�es
 **/

  public void emettreTrame(String DA,String EType,Donnees donnees) throws Exception
      {if (!this.estConnectee())
        throw new Exception("La machine n'est pas connecte a un hub");
       Trame t = new Trame(DA,this.getAdresseMAC(),EType,donnees);
		 System.out.println("la machine "+this.nom+" emet vers le hub la trame : " + t);
 	    this.hub.emettreTrame(this,t);
       this.tramesEnvoyees.add(t);
 		}



  /**
    la machine affiche la trame que lui a envoy� le hub
    la trame est rajout�e � la liste des trames re�ues
  **/
	public void recevoirTrame(Trame t )
      { System.out.println("trame re�ue par la machine " + this.nom + " : "+t);
		  this.tramesRecues.add(t);
		  try
		  {	
			  this.analyserTrameEthernet(t);
		  }
		  catch(Exception e)
		  {
			  System.out.println(e);
		  }
	}	
	
	public void envoyerArp(int code,String AdresseIPDestination,String AdresseMacDestination) throws Exception
	{
		
		if(code==1)
		{
			DonneesARP arp=new DonneesARP(code,this.getAdresseMAC(),this.getAdresseIP(),"00:00:00:00:00:00",AdresseIPDestination);
			this.emettreTrame("ff:ff:ff:ff:ff:ff","0806",arp);
		}
		else
		{
			DonneesARP arp=new DonneesARP(code,this.getAdresseMAC(),this.getAdresseIP(),AdresseMacDestination,AdresseIPDestination);
			this.emettreTrame(AdresseMacDestination,"0806",arp);

		}
	}
	
	public void envoyerIP(int Protocole, String adresseIPDestination,String adresseMACDestination,Donnees donneesNiveauSuperieurs) throws Exception
	{
		DonneesIP ip=new DonneesIP(4,Protocole, this.getAdresseIP(),adresseIPDestination,donneesNiveauSuperieurs);
		this.emettreTrame(adresseMACDestination,"0800",ip);
	}
	public void envoyerICMP(String adresseIPDestination, String adresseMACDestination,int type, int code) throws Exception
	{
		DonneesICMP icmp=new DonneesICMP(type,code);
		this.envoyerIP(01,adresseIPDestination,adresseMACDestination,icmp);
		//DonneesIP ip=new DonneesIP(4,01,this.getAdresseIP(),adresseIPDestination,icmp);
		//this.emettreTrame(adresseMACDestination,"08000",ip);
	}
	
	public void analyserTrameEthernet(Trame t) throws Exception
	{
		String eType=t.getEType();
		if(this.getAdresseMAC()==t.getDA())
		{
		
			if(eType.equals("0806"))
			{
				DonneesARP arp=(DonneesARP)t.getDonnees();
				this.analyserARP(arp);
			}
		
			if(eType.equals("0800"))
			{
				DonneesIP ip=(DonneesIP)t.getDonnees();
				this.analyserIP(ip,t.getSA());
			}
		}
	}
	
	public void analyserARP(DonneesARP arp) throws Exception
	{
		if( arp.getTPA()==this.getAdresseIP() )
		{
			if(arp.getOpCode()==2)
			{
				System.out.println("Adresse MAC recherchee: "+arp.getSHA());
			} 
			
			else
			{
				this.envoyerArp(2,arp.getSPA(),arp.getSHA());
			}
		}
	}
	
	public void analyserIP(DonneesIP ip, String macSource) throws Exception
	{
			if(this.getAdresseIP()==ip.getTIP())
			{
				if(ip.getProtocole()==01)
				{
					DonneesICMP icmp=(DonneesICMP)ip.getDonneesNiveauSuperieur();
					this.analyserICMP(icmp,ip.getSIP(),macSource);
				}
			}
			
	}

	public void analyserICMP(DonneesICMP icmp,String adresseIP,String macSource) throws Exception
	{
		if(icmp.getType()==8)
		{
			this.envoyerICMP(adresseIP,macSource,0,0);
		}
		
		if(icmp.getType()==0)
		{
			System.out.println("Adresse IP ping: "+adresseIP);
		}
	}
 }// end class










