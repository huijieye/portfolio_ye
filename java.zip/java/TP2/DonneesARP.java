// AdresseIP
public class DonneesARP extends Donnees
   {private int opCode;
	 private String SHA;
 	 private String SPA;
 	 private String THA;
 	 private String TPA;
	 
	 public DonneesARP(int opCode, String SHA, String SPA, String THA, String TPA ) throws Exception
	   {
		  super();
		 if ((opCode != 1) && (opCode !=2))
		   throw new Exception("opcode erron�");
		 Protocoles.verifierMac(SHA);
       Protocoles.verifierMac(THA);
       Protocoles.verifierIPMachine(SPA);
       Protocoles.verifierIPMachine(SPA);
		 this.opCode = opCode;
		 this.SHA = SHA;
		 this.SPA = SPA;
		 this.THA = THA;
		 this.TPA = TPA;
		}
		
	 public int getOpCode()
	   {return(this.opCode);}	

	 public String getSHA()
	   {return(this.SHA);}	

 	 public String getSPA()
	   {return(this.SPA);}	

	 public String getTHA()
	   {return(this.THA);}	

	 public String getTPA()
	   {return(this.TPA);}	

    public String toString()
	    { return(this.opCode+";"+this.SHA+";"+this.SPA+";"+this.THA+";"+this.TPA);
		 }
 
 }
