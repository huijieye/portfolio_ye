var products = ['orange','tomate','courgette','salade'];

for(i = 0; i < products.length; i++){
	console.log(products[i]);
}

var fruit = {
	'name': 'orange',
	'color': 'orange',
	'form':'round',
	printName: function () {
		return this.name;
	},
	printColor:function () {
		return this.printName()+': '+this.color;
	}
};

console.log(fruit.printName());
console.log(fruit.printColor());

switch (fruit.form){
	case 'round':
		console.log('round');
		break;
}


//***************MAIN*************************
$(document).ready(function() {
	$('p').each(function () {
		text = $(this).html()+' '+firstname;
		$(this).html(text);
	});

	$('p').each(function () {
		$(this).append(text);
	});

	$('p').append(firstname);
});

























