<script language="php">
	require_once("fonctions.php");

	if(isset($_POST['nomfichier'])&& isset($_POST['ligneTexte']))
	{
		ecritureTexte($_POST['nomfichier'],$_POST['ligneTexte']);
	}
		
	else 
		{
		print("Parametre manquant");
		}	
</script>
