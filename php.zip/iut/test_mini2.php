<script language="php">
	require_once("fonctions.php");

	if(isset($_GET['a']) && isset($_GET['b']))
		{
			print("Le minimum est ".mini2($_GET['a'],$_GET['b']));
		}
	else 
		{
		print("Parametre manquant");
		}	
</script>
