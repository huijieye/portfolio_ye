<script language="php">
	if(isset($_GET["prenom"]))
	{
		print("Bonjour ".$_GET["prenom"]." de la part de Florian");
	}
</script>
