<script language="php">
			require_once ("fonctions.php");
			envoyerAttributs("primeur.txt","1");
		</script>	
