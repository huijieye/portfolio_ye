<script language="php">
require_once("fonctionsBD.php");
	
	function getTableauNomsAttributsRequete($connexion,$requete)
	{
		return(getTableauNomsAttributsResultSet(executerRequete($connexion,$requete);
	}
	
	function getTableauNomsAttribusTable($connexion,$table)
	{
		$tab="select * from ".$table;
		return(getTableauNomsAttributsResultSet(executerRequete($connexion,$tab)
	}
	
</script>	
