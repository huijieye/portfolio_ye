<script language="php">

function etablirConnexion()
  {return(pg_connect("host=localhost dbname=barrachina user=barrachina password = mp"));
  }
 
function executerRequete ($connection,$requete)
  { $resultat=pg_exec($connection,$requete);
    return($resultat);
  } 
 
 function getTableauNomsAttributsResultSet($resultat)
   {$nbcols=pg_numfields($resultat);
    for($i=0;$i<$nbcols;$i++)
   	$tab[$i]=pg_fieldname($resultat,$i);
    return($tab); 
   }
	
function getTableauTuplesResultSet($resultat,$separateur,$attributs)
   { $tab = array();
     // nombre d'attributs
     $nbcols=pg_numfields($resultat);
     if ($attributs)
	    {$t = getTableauNomsAttributsResultSet($resultat);
             $tab[0] = implode($separateur,$t);
	     $j = 1;
	    } 
     else 
	$j =0;
	// nombre de tuples
      $nbligs=pg_numrows($resultat);
      for($row=0;$row<$nbligs;$row++)
	  {$s="";
	   for($i=0;$i<$nbcols-1;$i++)
	       $s=$s.pg_result($resultat,$row,$i).$separateur;
	   $s=$s.pg_result($resultat,$row,$i); // derniere ligne
	   $tab[$j] = $s;
	   $j++;
	  }  // for
    return($tab);
    }

</script>
