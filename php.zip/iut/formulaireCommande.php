<script language="php">


	function envoyerAttributs($nomfichier,$numero)
		{
			if(!file_exists($nomfichier))
				{
					print("fichier ionconuu");
				}
			
			else
			{
				$fichier=fopen($nomfichier,'r');
				$ligne=fgets($fichier);
				while($ligne!=null)
				{ $test=explode(";",$ligne);
		  		  print($test[$numero]);
			   	  $ligne=fgets($fichier);
				}
				
			}
			fclose($fichier);
		}
	
</script>	
