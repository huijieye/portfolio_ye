<script language="php">
	require_once("fonctions.php");

	if(isset($_GET['nomfichier']))
	{
		envoyerAttributs($_GET['nomfichier']);
	}
		
	else 
		{
		print("Parametre manquant");
		}	
</script>
