<script language="php">
	require_once("fonctions.php");

	if(isset($_POST['id'])&& isset($_POST['choix']))
	{
		$elem1=$_POST['id'];
		$elem2=$_POST['choix'];
		$a_afficher=$elem1.";".$elem2;
		ecritureTexte("commandes.txt",$a_afficher);
	}
		
	else 
		{
		print("Parametre manquant");
		}	
</script>
