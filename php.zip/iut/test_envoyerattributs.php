<script language="php">
	require_once("fonctions.php");

	if(isset($_GET['nomfichier'])&& isset($_GET['numero'])&& isset($_GET['separateur']))
	{
		envoyerAttributs($_GET['nomfichier'],$_GET['numero'],$_GET['separateur']);
	}
		
	else 
		{
		print("Parametre manquant");
		}	
</script>
