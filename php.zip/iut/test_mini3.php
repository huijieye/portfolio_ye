<script language="php">
	require_once("fonctions.php");

	if(isset($_GET['a']) && isset($_GET['b']) && isset($_GET['c']))
		{
			print("Le minimum est ".mini3($_GET['a'],$_GET['b'],$_GET['c']));
		}
	else 
		{
		print("Parametre manquant");
		}	
</script>
