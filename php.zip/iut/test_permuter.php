<script language="php">
	require_once("fonctions.php");

	if(isset($_GET['a']) && isset($_GET['b']) && isset($_GET['c']))
		{
			permuter($_GET['a'],$_GET['b'],$_GET['c']);
			print("a=".$_GET['a']." b=".$_GET['b']." c=".$_GET['c']);
		}
	else 
		{
		print("Parametre manquant");
		}	
</script>
