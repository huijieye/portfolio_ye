<script language="php">

	function mini2 ($a,$b)
	{
		if ($a<$b)
		{
			return $a;
		}
		return $b;	
	}
	
	function mini3($a,$b,$c)
		{
			return mini2(mini2($a,$b),$c);
		}
	
	function echanger(&$a,&$b)
		{
			$aux=$a;
			$a=$b;
			$b=$aux; 
		}
		

	
	function envoyerAttributs($nomfichier,$numero)
		{
			if(!file_exists($nomfichier))
				{
					print("fichier ionconuu");
				}
			
			else
			{
				$fichier=fopen($nomfichier,'r');
				$ligne=fgets($fichier);
				while($ligne!=null)
				{ 
					$test=explode(";", $ligne);
		  		  print("<option>".$test[$numero]."</option><br/>");
			   	  $ligne=fgets($fichier);
				}
			}
			fclose($fichier);
		}
		
	function ecritureTexte($fichier,$ligneTexte)
	{
		$temp=fopen($fichier,'a+');
		fputs($temp,$ligneTexte);
		fclose($temp);
	}
	
	
</script>	
