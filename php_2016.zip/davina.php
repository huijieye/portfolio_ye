<?php
Class TStat{
	private $_vehicule;
	private $_user;
	private $_date;
	private $_NbKim;
	public function setVehicule($vehicule){
		$this->_vehicule=$vehicule; 
	} 
	public function setUser($user){
		$this->_user=$user;
	}
	public function getVehicule(){
		return $this->_vehicule;
	}
}
$ligne1=new TStat();
$ligne1->setVehicule('CG-792-AV');
	echo $ligne1->getVehicule();
?>