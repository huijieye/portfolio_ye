<?php
	if(isset($_POST['nombres']))
	{
		$nombres=$_POST['nombres'];
		$tab=explode(' ', $nombres);

		echo '<pre>';
		print_r($tab);
		echo '</pre>';

		$i=0;
		$taille=count($tab);
		while($tab[$i]>$tab[$i+1]&&$i<$taille-1)
		{
			$i++;
		}
		echo $i;

		if($i!=$taille-1)
		{
			echo "<p>la liste n'est pas en ordre decroissante!</p>";
			for($i=1;$i<$taille;$i++)
			{
				$j=$i;
				$temp=$tab[$j];
				while($tab[$j-1]<$temp&&$j>0)
				{
					$tab[$j]=$tab[$j-1];
					$j--;
				}
				$tab[$j]=$temp;
			}
		}

		echo '<pre>';
		print_r($tab);
		echo '</pre>';
	}
?>