<?php

Class Stat{
	private $_date;
	private $_nbKm;

	const EXPERIENCE = 'vide';
	static $sagesse = 100;

  	public function getExperience() {
    	return self::EXPERIENCE;
  	}

  	public function getSagesse() {
    	return self::$sagesse;
  	}

	public function __construct($immat,$id,$date,$nbKm){
		$this->_immatriculation=$immat;
		$this->_id=$id;
		$this->_date=$date;
		$this->_nbKm=$nbKm;
	}

	public function setDate($date){
		$this->_date=$date;
	}

	public function setNbKm($nbKm){
		$this->_nbKm=$nbKm;
	}

	public function __toString(){
		echo '<br/>'.$this->_immatriculation.'<br/>'.$this->_id.'<br/>'.$this->_date.'<br/>'.$this->_nbKm.'<br/>';
	}

}

Class TVeh extends Stat{
	private $_immatriculation;
	private $_marque;
	private $_type;

	public function __construct($immat,$marque,$type){
		$this->_immatriculation=$immat;
		$this->_marque=$marque;
		$this->_type=$type;
	}

	public function getImmatriculation(){
		return $this->_immatriculation;
	}

	public function __toString(){
		echo '<br/>'.$this->_immatriculation.'<br/>'.$this->_marque.'<br/>'.$this->_type.'<br/>';
	}
}

Class TUtil extends Stat{
	private $_id;
	private $_nom;
	private $_service;

	public function __construct($id,$nom,$service){
		$this->_id=$id;
		$this->_nom=$nom;
		$this->_service=$service;
	}

	public function getId(){
		return $this->_id;
	}

	public function __toString(){
		echo '<br/>'.$this->_id.'<br/>'.$this->_nom.'<br/>'.$this->_service.'<br/>';
	}
}

echo "<br/>*******Vehicule*******";
$v1=new TVeh('CG-792-AV','Peugeot 206', 'Citadine');
$v1->__toString();

$v2=new TVeh('EF-456-FE','CLio c4', 'Renault');
$v2->__toString();

echo "<br/>*******Utilisateur*******";
$user1=new TUtil(36,'JEAN','DRH');
$user1->__toString();

$user2=new TUtil(56,'DAVINA','dev');
$user2->__toString();

echo "<br/>*******Statistique*******";
$ligne1=new Stat($v1->getImmatriculation(),$user1->getId(),'15/11/2016',332);
$ligne1->__toString();

$ligne2=new Stat($v2->getImmatriculation(),$user2->getId(),'14/11/2016',543);
$ligne2->__toString();

$ligne3=clone $ligne2;
$ligne3->setDate('15/11/2016');
$ligne3->setNbKm(345);

$tabStat=array($ligne1,$ligne2,$ligne3);

echo "<br/>******Tableau Statistique******";
echo '<pre>';
var_dump($tabStat);
echo '</pre>';

echo Personnage::EXPERIENCE.'<br/>';
echo Personnage::$sagesse;