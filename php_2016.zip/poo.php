<?php

Class Robot{
	protected $nom;
	protected $x=0; //EST
	protected $y=0; //NORD
	protected $direction="Est"; //Nord, Est, Sud, Ouest

//SETTER
	public function setNom($nom){
		$this->nom=$nom;
	}

	public function setPosition($x,$y){
			$this->x=$x;
			$this->y=$y;
	}

	public function setDirection($direction){
		switch ($direction) {
			case 'Nord':
				$this->direction=$direction;
				break;

			case 'Est':
				$this->direction=$direction;
				break;

			case 'Sud':
				$this->direction=$direction;
				break;

			case 'Ouest':
				$this->direction=$direction;
				break;

			default:
				$this->direction=null;
				echo "direction non correcte";
				break;
		}
	}

//GETTER
	public function getNom(){
		return $this->nom;
	}

	public function getPosition(){
		return "x = ".$this->x."; y = ".$this->y.";<br/>";
	}

	public function getDirection(){
		return $this->direction;
	}

//Fonctions spéciales
	public function __construct($nom,$x,$y,$direction){
		if(isset($nom)){
			$this->setNom($nom);
		}
		else{echo "Veuillez saisir le nom, svp";}

		if(isset($x)&&isset($y)&&isset($direction)){
			$this->setPosition($x,$y);
			$this->setDirection($direction);
		}
	}

//Méthodes
	public function move(){
		$this->x++;
		return 0;
	}

	public function right(){
		switch ($this->direction) {
			case 'Nord':
				$this->direction="Est";
				break;

			case 'Est':
				$this->direction="Sud";
				break;

			case 'Sud':
				$this->direction="Ouest";
				break;

			case 'Ouest':
				$this->direction="Nord";
				break;
		}
	}

	public function afficherEtat(){
		echo "<br/>Nom: ".$this->nom."<br/>Position: (".$this->x.",".$this->y.')<br/>Direction: '.$this->direction;
	}
	
}

Class RobotNG extends Robot{
	public function move(){
		for ($i=0; $i <3 ; $i++) { 
			parent::move();	
		}
	}

	public function left(){
		for ($i=0; $i <3 ; $i++) { 
			parent::right();	
		}
	}

	public function turnBack(){
		for ($i=0; $i <2 ; $i++) { 
			parent::right();	
		}
	}
}

$R = new Robot("hj",2,0,"Nord");

echo $R->getDirection().'<br/>';

$R->move();

echo "<br/>".$R->getPosition();

$R->right();

echo "<br/>".$R->getDirection();

$R->afficherEtat();


$Rn=new RobotNG("hj.1");
$Rn->afficherEtat();
$Rn->move();
$Rn->left();
$Rn->turnBack();
$Rn->afficherEtat();