<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Accueil</title>
    <meta name="description" content="Bonheur, un restaurant asiatique à Paris 11ème. On vous propose de la cuisine chinoise spéciale en région, les brochettes à volonté, le Karaoké pour fêter votre fêtes. Restauration à emporter."/>
   
  </head>

  <body>
    <div class="container">
      <?php
         include("commun_header.php");
	?>
      <!-- FIN D'EN TETE DE LA PAGE-->

      <!-- DEBUT du contenu de la page-->

      <main>
        <article> <!-- Présentation du resto -->
	  <header>
	    <h1>Le bonheur est un réstaurant asiatique qui vous propose:</h1> 
	  </header>

	  <div class="services">
	    <ul>
	      <li>des plats spécials aux regions</li>
	      <li>le barbecue à buffet à volonté</li>
	      <li>les salles karaoké pour célébrer des fêtes</li>
	   </ul>
	 </div>
	</article>

	<article class="bloc1"> <!-- Plats plus vendus -->
	  <div class="encadre">
	    <h2>Nos plats plus vendus de la semaine</h2>
	    <a href="plats.php?categorie=Plats Froids"><img src="images/poulet_maison.jpg" title="poulet_maison" alt="poulet_maison" width="350px"/></a>
	    <a href="plats.php?categorie=Brochettes"><img src="images/coeur de poulet.jpg" title="coeur de poulet" alt="coeur de poulet" width="350px"/></a>
	  </div>
	</article>

	<aside class="bloc2"> <!-- Horraires d'ouverture -->
	  <img src="images/photo1.jpg" title="magasin" alt="intérieur" width="400px"/> 
	  <section class="ouverture">
	    <P>Ouverture:</P>
	    <P>Du lundi au Jeudi: à partir de 18h</P>
	    <p>Du Vendredi au Dimanche: service en continue</p>
	  </section>
	  <img src="images/photo2.jpg" title="intérieur" alt="intérieur" width="400px"/>
	</aside>

      </main>

	<!--  Début du footer   -->
	<?php
	   include("commun_footer.php");
	?>

   </div>

	 <link rel="stylesheet" type="text/css" href="index.css">
 </body>
</html>
