<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Se connecter</title>
    <meta name="robots" content="noindex,nofollow"/>

  </head>

  <body>
    <div class="container">
      <?php
    	 include("commun_header.php");
    	 ?>

      <!-- FIN D'EN TETE DE LA PAGE-->

      <!-- DEBUT du contenu de la page-->
      <main>
	
	<div class="connect"> <!--formulaire de connexion-->
	  <form method="POST" action="connexion.php" name="connect">
	    <label for="email">Email</label>
	    <input type="text" name="email" id="email" placeholder="Votre Email" onchange="validerEmail(document.connect.email)"/>
	    
	    <label for="password">Mot de passe</label>
	    <input type="password" name="password" id="password" placeholder="Votre Mot de passe" onchange="verifierPwd(document.connect.password)"/>
	    
	    <input type="submit" name="envoyer" value="Se connecter"/>

	    <div class="nouveau"><a href="#inscrire">Nouveau chez Bonheur?</a></div>
	  </form>
	</div>


	<div class="inscrit"> <!--formulaire de l'inscription-->
	  <form method="POST" action="inscription.php" name="inscrire" id="inscrire">
	    <input type="text" name="prenom" id="prenom" placeholder="Prénom"/>
	    <input type="text" name="nom" id="nom" placeholder="Nom de famille"/>
	    <input type="email" name="email" id="email" placeholder="Adresse e-mail" onchange="validerEmail(document.inscrire.email)"/>
	    <input type="email" name="emailcc" id="emailcc" placeholder="Confirmer l'adresse e-mail" onchange="comparerEmail(document.inscrire.email,document.inscrire.emailcc)"/>
	    <input type="password" name="password" id="password" placeholder="Votre Mot de passe"/>
	    <input type="password" name="passwordcc" id="passwordcc" placeholder="Comfirmer le Mot de passe"/>
	    
	    <input type="submit" name="inscrit" value="Inscription" onclick="verifierPwd(password),comparerPwd()"/>
	  </form>
	</div>

      </main>
      

      <!--  Début du footer   -->

      <?php
         include("commun_footer.php");
	 ?>

    </div>

	    <link rel="stylesheet" type="text/css" href="login.css"/>
   	    <script type="text/javascript" src="login.js"></script>
  </body>
</html>
