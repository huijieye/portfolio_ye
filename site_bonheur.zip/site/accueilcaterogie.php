<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Accueil de Catalogue</title>
    <meta name="description" content=""/>
  </head>

  <body>
    <div class="container">

	<?php
	include("commun_header.php");
	require_once("produit.php");
	require_once("fonctions.php");

	echo '<main>';

		echo '<h1>Catalogue des plats asiatiques</h1>';
		echo '<div class="droite">';
	   	affichercategorie('Plats Froids',$tousPlats);	 	
		echo '</div>';

		echo '<div class="gauche">';
	    	affichercategorie('Brochettes',$tousPlats);
	  	echo '</div>';

		echo '<div class="milieu">';
	    	affichercategorie('Soupes et Plats Regionals',$tousPlats);
	  	echo '</div>';


	 	echo '<div class="platsD"> Notre plats à découvrir plutard</div>';

	echo '</main>';


	include("commun_footer.php");
	?>
    <link rel="stylesheet" type="text/css" href="accueilcaterogie.css">
   </div>
 </body>
</html>
