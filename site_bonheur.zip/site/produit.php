	
<?php
$tousPlats= array(
	'Plats Froids'=> array(
				array('plat'=>'Poulet à la sauce', 'prix' => '6€80'),
				array('plat'=>'Radis blanc mariné', 'prix' => '4€80'),
				array('plat'=>'Kimchi', 'prix' => '4€80'),
				array('plat'=>'Poulet en tranches cuit nature', 'prix' => '6€80'),
				array('plat'=>'Tofu aux oeufs', 'prix' => '4€80'),
				array('plat'=>'Tofu frit', 'prix' => '4€80'),
				array('plat'=>'Crabe rivière mariné façon "Wenzhou"', 'prix' => '18€00'),
				array('plat'=>'Poulet au moutarde chinoise', 'prix' => '7€50'),
				array('plat'=>'Edamame cuit à l\'eau salée', 'prix' => '4€80'),
				array('plat'=>'Tripes de boeuf à l\'huile piquante', 'prix' => '6€80'),
				array('plat'=>'Travers de porc croustillant', 'prix' => '6€80'),
				array('plat'=>'Haricot rouge croustillant', 'prix' => '12€90'),
				array('plat'=>'Squilles ivres', 'prix' => '12€90')
	),

	'Brochettes'=> array(
				array('plat'=>'Agneau', 'prix'=>'1€20'),
				array('plat'=>'Cuisse de poulet', 'prix'=>'1€50'),
				array('plat'=>'Chou fleur', 'prix'=>'1€00'),
				array('plat'=>'Courgette', 'prix'=>'1€20'),
				array('plat'=>'Gésiers de poulet', 'prix'=>'1€50'),
				array('plat'=>'Coeur de poulet', 'prix'=>'1€50'),
				array('plat'=>'Champignons', 'prix'=>'1€00'),
				array('plat'=>'Tofu sèché', 'prix'=>'1€00'),
				array('plat'=>'Gambas', 'prix'=>'2€50'),
				array('plat'=>'Boeuf', 'prix'=>'1€50'),
				array('plat'=>'Calamars', 'prix'=>'2€00'),
				array('plat'=>'Crevette', 'prix'=>'1€50')
	),

	'Soupes et Plats Regionals'=> array(
				array('plat'=>'Potage de boeuf aux céleris', 'prix' => '5€90'),
				array('plat'=>'Potage de fruits de mer aux céleris', 'prix' => '7€90'),
				array('plat'=>'Soupe de boulettes de poisson façon "wenzhou"', 'prix' => '5€90'),
				array('plat'=>'Soupe de jambon à la courge cireuse', 'prix' => '5€90'),
				array('plat'=>'Soupe de tomate aux oeufs', 'prix' => '4€50'),
				array('plat'=>'Filet de poisson au bouillon de choux fermentés', 'prix' => '18€00'),
				array('plat'=>'Filet de poisson au bouillon pimenté', 'prix' => '18€00'),
				array('plat'=>'Boeuf au bouillon pimenté', 'prix' => '14€80'),
				array('plat'=>'Boyaux de porc sautés aux piments dans le wok', 'prix' => '11€90'),
				array('plat'=>'Poulet à l\'impérial', 'prix' => '10€80'),
				array('plat'=>'Palourde sautée à la ciboulette', 'prix' => '8€80'),
				array('plat'=>'Bigomeaux à la sauce piquante', 'prix' => '15€50'),
				array('plat'=>'Gambas grillées', 'prix' => '18€80'),
				array('plat'=>'Crevettes au sel et au poivre', 'prix' => '11€80')

	)


);  

/*
echo '<pre>';
print_r($tousPlats);
echo '<pre>';
*/

?>

