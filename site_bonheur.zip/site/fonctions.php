<?php

//PHP ET FICHIER
function rajouterLigne($nomFich,$ligne)
{
	if(!file_exists($nomFich))
	{
	  $fich=fopen($nomFich,'w');
	  fclose($fich);
	}
	else
	{
	  $fich=fopen($nomFich,'a');
	  fputs($fich,$ligne.PHP_EOL);
	  fclose($fich);
	  return true;
	}
}

// PHP ET MYSQL
function connexion($email,$pwd)
{
	if(verifierEmail($email)==false)
	{
	 
	  $result=mysql_query("select password from Users where email='$email'");
		if(!$result)
		{die('Erreur execution:'.mysql_error());}
	  $mdp=mysql_result($result,0);
	  	if($mdp===$pwd)
		{
		echo 'Vous êtes connecté';
		//return true;
		}
		else
		{echo 'Mot de passe incorrect';}
	}
	else
	{
	 echo 'Votre email n\'existe pas.';
	}
	
}


function afficherLastId()
{
	$result=mysql_query("select max(id_user) from Users");
	$id=mysql_result($result,0);
	return $id;
}

function verifierEmail($email)
{
	
	$result=mysql_query("select * from Bonheur.Users where email='$email'");
	if(!$result)
	{die('Erreur execution:'.mysql_error());}
	
	$nb_ligne= mysql_num_rows($result);

	if($nb_ligne == 0)// 0=empty(email n'existe pas dans BD)
	{ return true;}
	else
	{ return false;}
}


function insertionLigne($id_user,$prenom,$nom,$email,$pwd)
{
$rep=mysql_query("insert into Bonheur.Users values ('$id_user','$prenom','$nom','$email','$pwd')");
	if(!$rep)
	{die('Erreur insertion'.mysql_error());}
	else
	{return true;}
}

//PHP Tableaux des plats

require_once("produit.php");


function afficherPlat($choix,$tousPlats)
{
	foreach($tousPlats as $categorie => $plat)
	{
		if($choix==$categorie)	
		{
			foreach($plat as $plat)
			{
			
				echo '<li>';
				echo '<input type="checkbox" name="'.$plat['plat'].'" id="'.$plat['plat'].'/>';	
				echo '<label for="'.$plat['plat'].'">'.$plat['plat'].'</label>';
				echo '</li>';
			}
		}
	
	}
}



function afficherPrix($nomPlat,$choix,$tousPlats)
{
	foreach($tousPlats as $categorie => $plat)
	{
		if($choix==$categorie)	
		{
			foreach($plat as $plat)
			{
				if($plat['plat']==$nomPlat)
				echo '<p>'.$plat['plat'].' : '.'<span class="gras">'.$plat['prix'].'</span>'.'</p>';
			}
		}
	
	}
}


function affichercategorie($choix,$tousPlats)
{
	
	foreach ($tousPlats as $categorie => $plat)
 	{
		if($categorie==$choix)
		echo '<a href="plats.php?categorie='.$categorie.'"title="'.$categorie.'">'.$categorie.'</a>';
		
 	}

}
