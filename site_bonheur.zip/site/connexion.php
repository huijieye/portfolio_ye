<?php

require_once("fonctions.php");

if(isset($_POST['email'])&&isset($_POST['password']))
{
	$email=htmlspecialchars((string)$_POST['email']);
	$pwd=htmlspecialchars((string)$_POST['password']);
	// verification des paramètres
	
	$con = mysql_connect("localhost","hj","tyghbn@94");

		if(!$con) 
		{ die('not connect'.mysql_error());}


	//établir une connexion mysql

		if(!mysql_select_db("Bonheur")) 
		{die('impossible de sélectionner la database'.mysql_error());}
	//sélectionner la database

	connexion(htmlspecialchars($email),htmlspecialchars($pwd));

}
