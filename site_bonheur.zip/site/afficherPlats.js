$(document).ready(function ()
{
	$('div').click(function()
	{
	  $('.plats').hide();
	  if ($(this).parent().find('.plats').css('display')=='none')
	  {
	    $(this).parent().find('.plats').show();
	  }
	  else{$(this).parent().find('.plats').hide();}
		
	});
});
