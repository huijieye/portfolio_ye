<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Contact</title>
    <meta name="robots" content="noindex,nofollow"/>
  </head>

  <body>
    <div class="container">
      <?php
    	 include("commun_header.php");
    	 ?>
      <!-- FIN D'EN TETE DE LA PAGE-->

      <!-- DEBUT du contenu de la page-->
      
      <main>
	

	<h1>La reservation des plats asiatiques</h1>
	<form method="POST" action="enregistreReserve.php">

	    <div class="comment"> <!-- mode -->
 		<input type="radio" name="mode" id="emporter" value="Plats à Emporter"/>
		<label for="emporter">Plats à Emporter</label>

		<input type="radio" name="mode" id="surPlace" value="Sur Place"/>
		<label for="surPlace">Sur Place</label>
	     </div>
	
			
		  
			<!-- Plats en service -->
		   <?php
			include("fonctions.php");

			echo '<div class="categorie">Plats Froids</div>';

			echo '<ul class="plats">';
			afficherPlat("Plats Froids",$tousPlats);
			echo '</ul>';

			/*echo '<div class="categorie">Brochettes</div>';

			echo '<ul class="plats">';
			afficherPlat("Brochettes",$tousPlats);
			echo '</ul>';*/
		   ?>

		  
		   
		
	</form>
      </main>
      
      <!--  Début du footer  --> 

      	 <?php
    	 include("commun_footer.php");
    	 ?>
	<link rel="stylesheet" type="text/css" href="reserve.css"/>
	<script type="text/javascript" src="jquery-1.12.0.js"></script>
        <script type="text/javascript" src="afficherPlats.js"></script>
    </div>
  </body>
</html>
