
      <header>
        <div id="logo">
          <a href="index.php"><img src="images/logo.gif" title:"logo" alt="logo non affiché"/></a>
        </div>

        <!-- menu de la page -->
        <nav>
          <ul id="menu_horizontal">
            <li class="rubrique"><a href="index.php">Accueil</a></li>
            <li class="rubrique"><a href="accueilcaterogie.php">Plats</a></li>  
            <li class="rubrique"><a href="erreur/404.html">Karaoké</a></li>
            <li class="rubrique"><a href="reserve.php">Réserver</a></li>
            <li class="rubrique"><a href="contact.php">Contact</a></li>
            <li class="rubrique"><a href="Login.php" id="log">Login</a></li>
          </ul>
	</nav>

	<!-- Bannière de la recherche -->
          <form action="search.php" method="GET" id="form" >
	    <div id="loupe">
	      <img src="images/loupe.gif" title="loupe" alt="loupe"/>
	    </div>
            <input type="search" name="rec" id="rec" value="recherche"/>
          </form>
     
      </header>
      <!-- FIN D'EN TETE DE LA PAGE-->
