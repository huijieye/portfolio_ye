
<!--  Début du footer  --> 

      <footer>
	<div class="RS">
	  <a href="https://www.facebook.com/"><img src="images/fb.png" title="facebook" alt="facebook" width="50px" height="50px" /></a>
	  <a href="https://twitter.com/"><img src="images/Tweeter.png" title="tweeter" alt="tweeter"width="50px" height="50px"/></a>
	</div>

	<div class="Mention">
	   <p><a href="index.php">Retour à l'accueil</a></p>
	  <p>©2015 Bonheur restaurant asiatique</p>
	  <p>3 Rue de la Présentation 75011 Paris  Tél: 0143578044</p>
	</div>
      </footer> 
