<html>
	<head>
		<title>Formulaire</title>
		<meta charset="utf-8"/>
	
	</head>
	<body>

		<?php
		require_once("fonctions.php");

			if(isset($_POST['civilite'])&&isset($_POST['prenomNom'])&&isset($_POST['email'])&&isset($_POST['message']))
			{
			$civil=(string)$_POST['civilite'];
			$prenomNom=(string)$_POST['prenomNom'];
			$email=(string)$_POST['email'];
			$message=(string)$_POST['message'];
			

			$ligne=htmlspecialchars($civil.';'.$prenomNom.';'.$email.';'.$message);
			//vérification des paramètres

				if (rajouterLigne('formRecu.txt',$ligne));// ajouter dans un fichier
				{
				  echo 'Votre information a été bien enregistré. On va vous contacter dès que possible.';
				}
				

			}

			else
			{
				echo 'il manque de paramètres';
			}
		?>
	</body>
</html>
