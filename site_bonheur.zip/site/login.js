function validerEmail(email)   
{  
	var format=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
 if (email.value.match(format))  
  {  
    return true;
  }  
    alert("l'adresse email n'est pas validée ");  
    return false;  
}  


function verifierPwd(password)
{
	var mp = password.value;
	
	if(mp.length<6) // un mot de passe contient au moins 6 caractères
	{
	  window.alert("verifiez votre password");
	   return false;
	}

	else  return true;
}


function comparerEmail(email,emailcc)
{
	var email1 = email.value;
	var email2 = emailcc.value;

	var x= email1.localeCompare(email2);//x= -1|0|1

	if(x != 0)//x=0>> 2 chaines sont egale
	{
	 window.alert("Les 2 emails sont différents");

	 return false;
	}
	else return true;
}

function comparerPwd()
{
	var pwd1=document.getElementById("password").value;
	var pwd2=document.getElementById("passwordcc").value;
	
	var x= pwd1.localeCompare(pwd2);//x= -1|0|1

	if(x != 0)//x=0>> egale
	{
	 window.alert("Les 2 mots de passe sont différents");

	return false;
	}
	else return true;
}
