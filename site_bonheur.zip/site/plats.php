<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Plats_froids</title>
    <meta name="description" content="Le restaurant Bonheur vous propose des plats chinois, comme des plats froids, des brochettes, des soupes et des plats régionals."/>
   
  </head>

  <body>
    <div class="container">
      <?php
    	 include("commun_header.php");
     
      //<!-- FIN D'EN TETE DE LA PAGE-->


      //<!-- DEBUT du contenu de la page-->
     	include("fonctions.php"); 
      
    	echo '<main>';

	       if(isset($_GET['categorie']))// verifie $categorie existe?
	       {
	        $choix=htmlspecialchars((string)$_GET['categorie']); 
			 
	           if($choix=='Plats Froids'||$choix=='Brochettes'||$choix=='Soupes et Plats Regionals')
	            {

		     echo '<div class="photo_prix">';
		       if($choix=='Plats Froids')
		       {
			echo '<h1>Les '.$choix.' du Bonheur</h1>';
			

			echo '<div class="container1">';	
				echo '<img src="images/poulet_maison.jpg" title="poulet sauce maison" alt="poulet sauce maison" width="180px" height="120px"/>';
			       afficherPrix('Poulet à la sauce',$choix,$tousPlats);

			       
			       echo '<img src="images/radis.jpg" title="radis blanc mariné" alt="Radis blanc mariné" width="180px"  height="120px"/>';
			       afficherPrix('Radis blanc mariné',$choix,$tousPlats);

			       
			       echo '<img src="images/kimchi.jpg" title="Kimchi" alt="Kimchi" width="180px"  height="120px"/>';
			       afficherPrix('Kimchi',$choix,$tousPlats);
		       echo '</div>';
		       
		       echo '<div class="container2">';
			       echo '<img src="images/poulet_cuit.jpg" title="poulet cuit nature" alt="poulet cuit nature" width="180px"  height="120px"/>';
			       afficherPrix('Poulet en tranches cuit nature',$choix,$tousPlats);

			       
			       echo '<img src="images/tofu_oeuf.jpg" title="Tofu aux oeufs" alt="Tofu aux oeufs" width="180px" height="120px"/>';
			       
			       afficherPrix('Tofu aux oeufs',$choix,$tousPlats);

			       
			       echo '<img src="images/tofu_frit.jpg" title="Tofu frit" alt="Tofu frit" width="180px"  height="120px"/>';
			       afficherPrix('Tofu frit',$choix,$tousPlats);
		       echo '</div>';

		  echo '</div>';//Fin photo_prix
		       
		       echo '<div class="container3">';
			       afficherPrix('Crabe rivière mariné façon "Wenzhou"',$choix,$tousPlats);
			       afficherPrix('Poulet au moutarde chinoise',$choix,$tousPlats);
		       echo '</div>';
		       
		       echo '<div class="container4">';
			       afficherPrix('Edamame cuit à l\'eau salée',$choix,$tousPlats);
			       afficherPrix('Tripes de boeuf à l\'huile piquante',$choix,$tousPlats);
		       echo '</div>';
		       
		       echo '<div class="container5">';
			       afficherPrix('Travers de porc croustillant',$choix,$tousPlats);
			       afficherPrix('Haricot rouge croustillant',$choix,$tousPlats);
			       afficherPrix('Squilles ivres',$choix,$tousPlats);
		       echo '</div>';

		       }// fin plats froids

		       if($choix=='Brochettes')
		       {
			echo '<h1>Les '.$choix.' du Bonheur</h1>';

			echo '<div class="container1">';
				echo '<img src="images/agneau.jpg" title="agneau" alt="agneau" width="180px" height="120px"/>';
				afficherPrix('Agneau',$choix,$tousPlats);

			       
			       echo '<img src="images/cuisse de poulet.jpg" title="cuisse de poulet" alt="cuisse de poulet" width="180px"  height="120px"/>';
			       afficherPrix('Cuisse de poulet',$choix,$tousPlats);

			       
			       echo '<img src="images/chou fleur.jpg" title="chou fleur" alt="chou fleur" width="180px"  height="120px"/>';
			       afficherPrix('Chou fleur',$choix,$tousPlats);
		       echo '</div>';
		       

		       echo '<div class="container2">';		       
			       echo '<img src="images/courgette.jpg" title="Courgette" alt="Courgette" width="180px"  height="120px"/>';
			       afficherPrix('Courgette',$choix,$tousPlats);

			       
			       echo '<img src="images/gesier de poulet.jpg" title="gesiers de poulet" alt="gesiers de poulet" width="180px" height="120px"/>';
			       
			       afficherPrix('Gésiers de poulet',$choix,$tousPlats);

			       
			       echo '<img src="images/coeur de poulet.jpg" title="coeur de poulet" alt="coeur de poulet" width="180px"  height="120px"/>';
			       afficherPrix('Coeur de poulet',$choix,$tousPlats);	       
		       echo '</div>';

		  echo '</div>';//Fin photo_prix
		       
		       echo '<div class="container3">';
			       afficherPrix('Champignons',$choix,$tousPlats);
			       afficherPrix('Tofu sèché',$choix,$tousPlats);
		       echo '</div>';
		       
		       echo '<div class="container4">';
			       afficherPrix('Gambas',$choix,$tousPlats);
			       afficherPrix('Calamars',$choix,$tousPlats);
		       echo '</div>';
		       
		       echo '<div class="container5">';
		       		afficherPrix('Crevette',$choix,$tousPlats);
		       echo '</div>';

		       }// fin brochettes

			if($choix=='Soupes et Plats Regionals')
			{
			echo '<h1>Les '.$choix.' du Bonheur</h1>';
			echo '<div class="container1">';			
			echo '<p>page en développement</p>';
			}
	       
	            }// fin if $choix==
	       }//fin if $categorie
	       else
	       {
	       echo 'paramètres manqunt';
	       }     
    echo '</main>';
	       //Début du footer
               include("commun_footer.php");
	       ?>

	  </div>
	 <link rel="stylesheet" type="text/css" href="plats.css">
  </body>
</html>
