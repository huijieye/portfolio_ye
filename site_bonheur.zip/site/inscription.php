<?php

require_once("fonctions.php");

if(isset($_POST['prenom'])&&isset($_POST['nom'])&&isset($_POST['email'])&&isset($_POST['password']))
{
$prenom=htmlspecialchars((string)$_POST['prenom']);
$nom=htmlspecialchars((string)$_POST['nom']);
$email=htmlspecialchars((string)$_POST['email']);
$pwd=htmlspecialchars((string)$_POST['password']);

$con = mysql_connect("localhost","hj","tyghbn@94");

	if(!$con) 
	{ die('not connect'.mysql_error());}


//établir une connexion mysql

	if(!mysql_select_db("Bonheur")) 
	{die('impossible de sélectionner la database'.mysql_error());}
//sélectionner la database


$id_user= afficherLastId() +1; 
//dernier index

	

	if((verifierEmail($email)== 1) && (!(empty($pwd))))// si email validé ET mot de pass non vide
	//1= True(Email validé), 0=False
	{
	 if(insertionLigne($id_user,$prenom,$nom,$email,$pwd)==1)
		{print("compte crée");}
	}
	else
	{echo 'verifier votre email ou mot de pass';}
//verification et insertion

	mysql_close($con);
//deconnexion
}
else
{
	echo 'manque de paramètres';
}

