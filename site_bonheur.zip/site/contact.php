<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Contact</title>
    <meta name="robots" content="noindex,nofollow"/>
   
  </head>

  <body>
    <div class="container">
      <?php
    	 include("commun_header.php");
    	 ?>
      <!-- FIN D'EN TETE DE LA PAGE-->

      <!-- DEBUT du contenu de la page-->
      
      <main>
	<!-- Formulaire de contact -->
	<form method="POST" action="enregistreFormulaire.php" name="form">
     	  <h1>Nous contacter</h1>

	  <label class="civilite">Civilité</label>
	  <input type="radio" name="civilite" value="M" id="M"/>
	  <label for="M" class="civilite">Monsieur</label>
	  <input type="radio" name="civilite" value="F" id="F"/>
	  <label for="F" class="civilite">Madame</label>

	  <label for="prenomNom">Votre Prénom Nom *</label>
	  <input type="text" name="prenomNom" id="prenomNom" placeholder="Votre prénom Nom" required autofocus/>

	  <label for="email">Votre Email *</label>
	  <input type="email" name="email" id="email" placeholder="Votre email" required onchange="validerEmail(document.form.email)"/>

	  <label for="object">Objet</label>
	  <input type="text" name="object" id="object" placeholder="L'objet"/>
	  
	  <label for="message">Votre Message</label>
	  <textarea name="message" id="message"></textarea>

	  
	  <input type="reset" value="Remise à zéro"/>
	  <input type="submit" value="Envoyer"/>

	  <p>Vous pouvez aussi nous rejoindre par téléphone suivante: 0143578044</p>

	</form>
      </main>
      
      <!--  Début du footer  --> 

      <?php
    	 include("commun_footer.php");
    	 ?>

    </div>
	 <link rel="stylesheet" type="text/css" href="contact.css">
	<script type="text/javascript" src="login.js"></script>
  </body>
</html>
